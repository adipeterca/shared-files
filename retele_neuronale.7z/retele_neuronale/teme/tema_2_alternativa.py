import gzip
import pickle
import random

import numpy as np


class Network:
    LEARNING_RATE = 0.5
    INPUT_SIZE = 784
    HIDDEN_SIZE = 100
    OUTPUT_SIZE = 10
    BATCH_SIZE = 10
    ITERATIONS = 10

    def __init__(self):
        self.weights = [
            np.random.randn(self.HIDDEN_SIZE, self.INPUT_SIZE),
            np.random.randn(self.OUTPUT_SIZE, self.HIDDEN_SIZE)
        ]
        self.biases = [
            np.random.randn(self.HIDDEN_SIZE, 1),
            np.random.randn(self.OUTPUT_SIZE, 1)
        ]

    def sigmoid(self, z):
        return 1.0 / (1.0 + np.exp(-z))

    def softmax(self, z):
        aux = np.exp(z)
        return aux / np.sum(aux)

    def sigmoid_derivative(self, z):
        return self.sigmoid(z) * (1 - self.sigmoid(z))

    def train_feedforward(self, x):
        layers_sums = []
        layers_activations = []

        layers_sums.append(self.weights[0].dot(x) + self.biases[0])
        layers_activations.append(self.sigmoid(layers_sums[0]))

        layers_sums.append(self.weights[1].dot(layers_activations[0]) + self.biases[1])
        layers_activations.append(self.softmax(layers_sums[1]))

        return layers_sums, layers_activations

    def train_backpropagation(self, layers_sums, layers_activations, t, x):
        weights_update = [
            np.zeros(weight.shape) for weight in self.weights
        ]
        biases_update = [
            np.zeros(bias.shape) for bias in self.biases
        ]

        delta = layers_activations[1] - t
        biases_update[1] = delta
        weights_update[1] = delta.dot(layers_activations[0].T)

        delta = self.weights[1].T.dot(delta) * self.sigmoid_derivative(layers_sums[0])
        biases_update[0] = delta
        weights_update[0] = delta.dot(x.T)

        return weights_update, biases_update

    def training(self, training_set, test_set=None):
        v = list(zip(training_set[0], training_set[1]))
        for i, (x, t) in enumerate(v):
            v[i] = (x.reshape(784, 1), np.array([1 if i == t else 0 for i in range(10)]).reshape(10, 1))
        batch_count = len(v) // self.BATCH_SIZE

        for _ in range(self.ITERATIONS):
            random.shuffle(v)
            for i in range(batch_count):
                if i % 1000 == 0:
                    print(f'{i}/{batch_count}')
                batch_weights_update = [
                    np.zeros(weight.shape) for weight in self.weights
                ]
                batch_biases_update = [
                    np.zeros(bias.shape) for bias in self.biases
                ]
                for j in range(self.BATCH_SIZE):
                    current_index = i * self.BATCH_SIZE + j
                    layers_sums, layers_activations = self.train_feedforward(v[current_index][0])
                    weights_update, biases_update = self.train_backpropagation(layers_sums, layers_activations,
                                                                               v[current_index][1], v[current_index][0])
                    for k in range(len(batch_weights_update)):
                        batch_weights_update[k] += weights_update[k]
                        batch_biases_update[k] += biases_update[k]

                for k in range(len(self.weights)):
                    self.weights[k] -= self.LEARNING_RATE * batch_weights_update[k] / self.BATCH_SIZE
                    self.biases[k] -= self.LEARNING_RATE * batch_biases_update[k] / self.BATCH_SIZE
            if test_set is not None:
                self.test(test_set)

    def predict(self, x):
        layers_sums, layers_activations = self.train_feedforward(x.reshape(784, 1))
        return np.argmax(layers_activations[1])

    def test(self, test_set):
        v = list(zip(test_set[0], test_set[1]))
        correct = 0
        total = 0
        for x, t in v:
            guess = self.predict(x)
            if guess == t:
                correct += 1
            total += 1
        print(f'Accuracy: {correct / total * 100}% - {correct}/{total}')


def main():
    with gzip.open('mnist.pkl.gz', 'rb') as f:
        train_set, valid_set, test_set = pickle.load(f, encoding='latin')
        network = Network()
        network.training(train_set, test_set)
        network.test(test_set)


if __name__ == '__main__':
    main()
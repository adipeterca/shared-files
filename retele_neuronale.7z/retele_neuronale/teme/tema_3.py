import pickle
import numpy as np
import gzip
from math import sqrt
import random

def initData():
    # Read the data
    with gzip.open('mnist.pkl.gz', 'rb') as fin:
        TRAIN, VALID, TEST = pickle.load(fin, encoding='latin')

    train_set = []
    valid_set = []
    test_set = []
    
    train_set = list(zip(TRAIN[0], TRAIN[1]))
    for i in range(len(train_set)):
        train_set[i] = (train_set[i][0].reshape(784, 1), train_set[i][1])
    print("Finished training set...")

    valid_set = list(zip(VALID[0], VALID[1]))
    for i in range(len(valid_set)):
        valid_set[i] = (valid_set[i][0].reshape(784, 1), valid_set[i][1])
    print("Finished validation set...")

    test_set = list(zip(TEST[0], TEST[1]))
    for i in range(len(test_set)):
        test_set[i] = (test_set[i][0].reshape(784, 1), test_set[i][1])
    print("Finished testing set...")

    return train_set, valid_set, test_set

def sigmoidActivation(matrix):
    # matrix = 1 / ( 1 + np.exp(-matrix))
    # return matrix
    for i in range(0, matrix.shape[0]):
        for j in range(0, matrix.shape[1]):
            matrix[i][j] = 1 / (1 + np.exp(-matrix[i][j]))

def softmaxActivation2(matrix):
    aux = np.exp(matrix)
    return aux / np.sum(aux)

def softmaxActivation(matrix):
    eSum = 0
    for i in range(0, matrix.shape[0]):
        for j in range(0, matrix.shape[1]):
            eSum += np.exp(matrix[i][j])
    for i in range(0, matrix.shape[0]):
        for j in range(0, matrix.shape[1]):
            matrix[i][j] = np.exp(matrix[i][j]) / eSum

class NeuralNetwork:
    def __init__(self):

        # input_layer comes as a function parameter

        lower = -1.0 / sqrt(784)
        upper = 1.0 / sqrt(784)
        self.weights_ih = np.random.uniform(low=lower, high=upper, size=(100, 784))
        # self.weights_ih = np.random.rand(100, 784)

        self.bias_ih = np.random.random((100, 1))

        lower = -1.0 / sqrt(100)
        upper = 1.0 / sqrt(100)
        self.weights_ho = np.random.uniform(low=lower, high=upper, size=(10, 100))
        self.bias_ho = np.random.random((10, 1))

        # output_layer is calculated on the spot 
        self.originalLearningRate = 0.2

        # Momentum coefficient (for L2 regularization)
        self.momentum = 0.9

        # Regularization coefficient
        self.regularization = 2

    def guess(self, inputs):
        # Calculate the weighted sum from input to hidden (100, 1)
        sum_ih = self.weights_ih.dot(inputs) + self.bias_ih

        # Pass it thought the sigmoid activation function
        sigmoidActivation(sum_ih)

        # Calculate the weighted sum from hidden to output (10, 1)
        sum_oh = self.weights_ho.dot(sum_ih) + self.bias_ho

        # Pass it through the softmax activation function
        softmaxActivation(sum_oh)

        return np.argmax(sum_oh)
    
    # This function returns 4 elements: the weight and bias deltas from IH and the weight and bias deltas from HO
    # without updating anything
    def train(self, inputs, target):
         # Calculate the weighted sum from input to hidden (100, 1)
        sum_ih = self.weights_ih.dot(inputs) + self.bias_ih

        # Pass it thought the sigmoid activation function
        sigmoidActivation(sum_ih)

        # Calculate the weighted sum from hidden to output (10, 1)
        sum_ho = self.weights_ho.dot(sum_ih) + self.bias_ho

        # Pass it through the softmax activation function
        # softmaxActivation(sum_ho)
        sum_ho = softmaxActivation2(sum_ho)

        # Make a target matrix
        target_matrix = np.zeros((10, 1))
        target_matrix[target][0] = 1

        # Get the output layer error using the cross entropy function (10, 1)
        output_error = sum_ho - target_matrix

        # Calculate the hidden layer errors
        # Formula: y^2 ** (1 - y^2) ** weightsTranposed *** error, where ** - hadamard product and *** - matrix product
        hidden_error = sum_ih * (1 - sum_ih) * (np.transpose(self.weights_ho).dot(output_error))

        # Calculate weights deltas
        weights_deltas_ho = output_error.dot(np.transpose(sum_ih)) * self.learningRate
        weights_deltas_ih = hidden_error.dot(np.transpose(inputs)) * self.learningRate

        # Calculate bias deltas
        bias_deltas_ho = output_error * self.learningRate
        bias_deltas_ih = hidden_error * self.learningRate

        # print(weights_deltas_ho)

        return weights_deltas_ih, bias_deltas_ih, weights_deltas_ho, bias_deltas_ho

    def testAccuracy(self, test_set, maxTests = -1):
        if maxTests == -1:
            maxTests = len(test_set)

        correct = 0
        for e, pair in enumerate(test_set):
            if e == maxTests:
                break

            # print(f"Running test number {e}...")
            output = self.guess(pair[0])
            if output == pair[1]:
                correct += 1
            else:
                pass
                # print(f"[TEST {e}] Guessed {output} instead of {pair[1]}")
    
        print("----------------------------------------")
        print(f"Accuracy: {correct}/{maxTests}")
        print(f"Accuracy percetange: {correct / maxTests * 100}\n")
    
    # Given a dataset, it trains the network using a minibatch approach
    def runEpoch(self, _set, minibatch_size = 100):
        random.shuffle(_set)

        self.learningRate = self.originalLearningRate / minibatch_size

        friction_ih = np.zeros(self.weights_ih.shape)
        friction_ho = np.zeros(self.weights_ho.shape)

        for i in range(0, len(_set), minibatch_size):
            minibatch = _set[i:i+minibatch_size]

            weights_deltas_ih = np.zeros((100, 784))
            bias_deltas_ih = np.zeros((100, 1))
            
            weights_deltas_ho = np.zeros((10, 100))
            bias_deltas_ho = np.zeros((10, 1))

            # Iterate through the selected minibatch
            for inputs, target in minibatch:
                d1, d2, d3, d4 = self.train(inputs, target)
                
                weights_deltas_ih += d1
                bias_deltas_ih += d2

                weights_deltas_ho += d3
                bias_deltas_ho += d4
            
            # Now that a minibatch is complete, update the coresponding weights
            friction_ih = friction_ih * self.momentum + weights_deltas_ih / minibatch_size
            friction_ho = friction_ho * self.momentum + weights_deltas_ho / minibatch_size

            self.weights_ih -= friction_ih + (self.regularization * self.originalLearningRate / len(_set)) * self.weights_ih
            self.bias_ih -= bias_deltas_ih / minibatch_size

            self.weights_ho -= friction_ho + (self.regularization * self.originalLearningRate / len(_set)) * self.weights_ho
            self.bias_ho -= bias_deltas_ho / minibatch_size


if __name__ == "__main__":

    train_set, valid_set, test_set = initData()

    nn = NeuralNetwork()
    
    for i in range(5):
        print(f"Running epoch number {i} for the train set...")
        nn.runEpoch(train_set, 10)
        random.shuffle(test_set)
        # nn.testAccuracy(test_set, 1000)

    print("\n\nB E F O R E")
    nn.testAccuracy(test_set)

    for i in range(5):
        print(f"Running epoch number {i} for the valid set...")
        nn.runEpoch(valid_set, 10)
        random.shuffle(test_set)
        # nn.testAccuracy(test_set, 1000)

    print("\n\nF I N A L   R E S U L T")
    nn.testAccuracy(test_set)
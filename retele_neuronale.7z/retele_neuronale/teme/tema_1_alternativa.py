import numpy as np
import gzip
import pickle
import threading as td
import time
import random
import datetime

# Read the data
with gzip.open("mnist.pkl.gz", "rb") as fd:
    training_set, validation_set, testing_set = pickle.load(fd, encoding="latin")

weights = np.random.random((10, 784))
biases = np.random.random((10, 1))

learningRate = 0.05

THETA = 0 # 150 # 392

batchSize = 10000

# Function for preparing the values
def initData():
    global weights
    global biases
    global training_set
    global validation_set
    global testing_set
    global learningRate
    
    # weights = weights * 2 - 1
    # biases = biases * 2 - 1

    # Bad choice dont do this!!
    # for i in range(0, len(training_set[0])):
    #     training_set[0][i] = training_set[0][i] * 2 - 1
    # for i in range(0, len(validation_set[0])):
    #     validation_set[0][i] = validation_set[0][i] * 2 - 1
    # for i in range(0, len(testing_set[0])):
    #     testing_set[0][i] = testing_set[0][i] * 2 - 1

def shuffleSet(dataset):
    datasetTuple = []
    for i in range(0, len(dataset[0])):
        datasetTuple.append((dataset[0][i], dataset[1][i]))
    random.shuffle(datasetTuple)
    for i in range(0, len(datasetTuple)):
        dataset[0][i] = datasetTuple[i][0]
        dataset[1][i] = datasetTuple[i][1]
    return dataset

def train(minibatch):
    global weights
    global biases
    global THETA

    weightsDeltas = np.zeros((10, 784))
    biasesDeltas = np.zeros((10, 1))
    for i in range(0, len(minibatch[0])):
        # Prep the inputs
        inputs = np.zeros((784, 1))
        for j in range(0, 784):
            inputs[j][0] = minibatch[0][i][j]

        # Get the target value
        target = np.zeros((10, 1))
        target[minibatch[1][i]][0] = 1

        # Get the output
        output = weights.dot(inputs) + biases
        for j in range(0, len(output)):
            if output[j][0] >= THETA:
                output[j][0] = 1
            else:
                output[j][0] = 0

        # Calculate the error
        error = target - output

        # Calculate the deltas for weights
        weightsDeltas = weightsDeltas + error.dot(np.transpose(inputs)) * learningRate

        # Calculate the deltas for biases
        biasesDeltas = biasesDeltas + error * learningRate
    
    return weightsDeltas, biasesDeltas

def printAccuracy(filename):
    global batchSize

    if filename:
        fin = open(filename, "w")
    accuracy = 0.0
    for i in range(0, batchSize):
        
        inputs = np.zeros((784, 1))
        for j in range(0, 784):
            inputs[j][0] = testing_set[0][i][j]

        output = weights @ inputs + biases
        
        maximum = output[0][0]
        guess = 0
        for j in range(10):
            if output[j][0] > maximum:
                maximum = output[j][0]
                guess = j

        if filename:
            fin.write(f"Output: {guess}, target: {testing_set[1][i]}\n")
        if guess == testing_set[1][i]:
            accuracy += 1
    print(f"\nGot {int(accuracy)} cases correct out of {len(testing_set[0])}...")
    accuracy = accuracy / len(testing_set[0]) * 100
    print(f"The overall accuracy is {accuracy}...")

    if filename:
        fin.close()

    
if __name__ == "__main__":

    startTime = datetime.datetime.now()

    # Select whether or not to load/retrain the network (and save it)
    saveNN = True

    if saveNN:
        initData()

        noOfEpochs = 1

        # Rough training
        while noOfEpochs < 5:
            print(f"\nStarting epoch number {noOfEpochs}...")

            # Shuffle the training_set
            training_set = shuffleSet(training_set)

            # Run an epoch
            for i in range(0, len(training_set[0]), batchSize):
                # Prep a minibatch
                minibatch = [None, None]
                minibatch[0] = training_set[0][i:i + batchSize]
                minibatch[1] = training_set[1][i:i + batchSize]

                # Update the weights and biases
                weightsDeltas, biasesDeltas = train(minibatch)

                weights += weightsDeltas
                biases += biasesDeltas

            print(np.transpose(weights)[100])
            printAccuracy("accuracy_out_" + str(noOfEpochs))

            noOfEpochs += 1
            learningRate = learningRate * 0.5

        noOfEpochs = 1
        learningRate = 0.01
        # Validation training
        while noOfEpochs < 8:
            print(f"Starting epoch number (for validation) {noOfEpochs}...")
            
            # Shuffle validation set
            validation_set = shuffleSet(validation_set)

            # Run an epoch
            for i in range(0, len(validation_set[0]), batchSize):
                # Prep a minibatch
                minibatch = [None, None]
                minibatch[0] = validation_set[0][i:i + batchSize]
                minibatch[1] = validation_set[1][i:i + batchSize]

                # Update the weights and biases
                weightsDeltas, biasesDeltas = train(minibatch)
                
                weights += weightsDeltas
                biases += biasesDeltas
            noOfEpochs += 1
            printAccuracy("accuracy_out_validation_" + str(noOfEpochs))

        # Save the weights to a file
        with open("weights", "wb") as wfout:
            pickle.dump(weights, wfout)
        # Save the biases to a file
        with open("biases", "wb") as bfout:
            pickle.dump(biases, bfout)
    else:
        # Load the weights from a file
        with open("weights", "rb") as wfout:
            weights = pickle.load(wfout)
        # Load the biases to a file
        with open("biases", "rb") as bfout:
            biases = pickle.load(bfout)
    

    # Print the accuracy
    printAccuracy("output2.txt")
    
    # Print time
    finishTime = datetime.datetime.now()
    print(f"\n\nStart time: {startTime}")
    print(f"Finish time: {finishTime}")
    print(f"Total time execution: {finishTime - startTime}")
import gzip
import pickle
import random

import numpy as np


class Perceptron:
    LEARNING_RATE = 0.01

    def __init__(self, n, digit):
        self.weights = np.random.rand(n)
        self.b = random.random()
        self.digit = digit

    def activation(self, x):
        if x > 0:
            return 1
        return 0

    def training(self, training_set):
        all_classified = False
        iterations = 5
        v = list(zip(training_set[0], training_set[1]))
        while not all_classified and iterations > 0:
            all_classified = True
            for x, t in v:
                target = 1 if t == self.digit else 0
                z = self.weights.dot(x) + self.b
                output = self.activation(z)
                self.weights = self.weights + (target - output) * x * self.LEARNING_RATE
                self.b = self.b + (target - output) * self.LEARNING_RATE
                if output != target:
                    all_classified = False
            iterations -= 1

    def get_output(self, x):
        return self.weights.dot(x) + self.b


def network_predict(network, x):
    outputs = [p.get_output(x) for p in network]
    maxim = outputs[0]
    guess = 0
    for i in range(10):
        if outputs[i] > maxim:
            maxim = outputs[i]
            guess = i
    return guess


def test(network, test_set):
    v = list(zip(test_set[0], test_set[1]))
    correct = 0
    total = 0
    for x, t in v:
        guess = network_predict(network, x)
        if guess == t:
            correct += 1
        total += 1
    print(f'Accuracy: {correct / total * 100}% - {correct}/{total}')


def main():
    with gzip.open('mnist.pkl.gz', 'rb') as f:
        train_set, valid_set, test_set = pickle.load(f, encoding='latin')
        network = [Perceptron(784, i) for i in range(10)]
        for i in network:
            i.training(train_set)
        test(network, test_set)

if __name__ == '__main__':
    main()
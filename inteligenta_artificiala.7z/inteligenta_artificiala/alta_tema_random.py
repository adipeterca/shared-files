import numpy as np
import random
from math import sqrt

# The number of possible states
state_size = 16

# The total amount of actions: UP, DOWN, LEFT, RIGHT
action_size = 4

# Learning rate (how much to account for the new found value)
LEARNING_RATE = 0.4

# The discount factor: which rewards to prioritize
GAMMA = 0.7

# Ice locations
icePositions = [(1, 1), (2, 3), (3, 0), (1, 3)]
# icePositions = [(2, 3), (3, 0), (1, 3)]

# Reward matrix
rewards = np.zeros((4, 4))
# for i in range(4):
#     for j in range(4):
#         rewards[i][j] = 1 / (sqrt((i - 3)**2 + (j - 3)**2) + 1)
# Negative rewards for losing positions
for e in icePositions:
    rewards[e[0]][e[1]] = -1

# Positive reward for wining
rewards[3][3] = 20

# Given a state and an action, return the next state (if the action is valid)
# Else, return None
def move(currentState, action):
    if action == 'UP':
        if currentState[0] != 0:
            return (currentState[0] - 1, currentState[1])
        # Invalid action
        return None
    
    if action == 'RIGHT':
        if currentState[1] != 3:
            return (currentState[0], currentState[1] + 1)
        return None

    if action == 'DOWN':
        if currentState[0] != 3:
            return (currentState[0] + 1, currentState[1])
        return None

    if action == 'LEFT':
        if currentState[1] != 0:
            return (currentState[0], currentState[1] - 1)
        return None
    return None

# Returns the given state index in the Q Table
def getStateIndex(state):
    return state[0] * 4 + state[1]

# Returns a VALID (random) next action
def getRandomValidAction(state):
    validStates = []
    if move(state, 'UP') != None:
        validStates.append('UP')
    if move(state, 'DOWN') != None:
        validStates.append('DOWN')
    if move(state, 'LEFT') != None:
        validStates.append('LEFT')
    if move(state, 'RIGHT') != None:
        validStates.append('RIGHT')
    return random.sample(validStates, 1)[0]

# Given a state, returns the next max valid action
def getMaxValidAction(state):
    max = None
    actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
    for e, a in enumerate(actions):
        # If we can make that move
        if move(state, a) != None:
            if max == None or Q[getStateIndex(state)][getActionIndex(a)] > Q[getStateIndex(state)][max]:
                max = e
            elif Q[getStateIndex(state)][getActionIndex(a)] == Q[getStateIndex(state)][max] and random.random() < 0.5:
                max = e
                
        else:
            Q[getStateIndex(state)][getActionIndex(a)] = -10
    return actions[max]

# Returns the given action index in the Q Table
def getActionIndex(state):
    if state == 'UP':
        return 0
    elif state == 'DOWN':
        return 1
    elif state == 'LEFT':
        return 2
    return 3

if __name__ == '__main__':
    
    # Init Q table
    # The table is as follows:
    #               UP DOWN LEFT RIGHT
    #   STATE_0_0
    #   STATE_0_1
    #   STATE_0_2
    #   STATE_0_3
    #   STATE_1_0
    #   ..............................
    #   STATE_3_3
    Q = np.zeros((state_size, action_size))

    # Initial state
    currState = (0, 0)

    # Training
    numberOfGames = 10000
    numberOfIterations = 100
    
    epsilon = 1
    gameDone = False
    for i in range(numberOfGames):

        if i % 100 == 0:
            print(f"Started game {i + 1}...")
        
        # Initial state
        currState = (0, 0)
        
        visitedStates = []
        # for ii in range(numberOfIterations):
        ii = 0
        gameDone = False
        while not gameDone:
            ii += 1
            # if ii % 100 == 0 or True:
            #     print(f"Started iteration {ii + 1}...")

            # Do a random action
            if random.random() < epsilon:
                action = getRandomValidAction(currState)
                actionIndex = getActionIndex(action)
            else:
                action = getMaxValidAction(currState)
                actionIndex = getActionIndex(action)
            
            # Decrease epsilon
            # epsilon *= 0.995

            # Add the current state as visited
            visitedStates.append(currState)

            # Update Q Table
            stateIndex = getStateIndex(currState)
            nextState = move(currState, action)
            if nextState == None:
                reward = -1
            # elif currState in visitedStates:
            #     reward = 0
            else:
                reward = rewards[nextState[0]][nextState[1]] 
            # Q[stateIndex][actionIndex] = Q[stateIndex][actionIndex] + LEARNING_RATE * (reward + GAMMA * np.max(Q[nextState]) - Q[stateIndex][actionIndex])
            Q[stateIndex][actionIndex] = reward + GAMMA * np.max(Q[nextState])

            # If the agent died, break
            if nextState in icePositions:
                print(f"Finished game {i + 1} early (by death) on iteration {ii + 1}. State: {nextState} from state {currState}")
                break

            # If the agent won, break
            if nextState == (3, 3):
                print(f"Finished game {i + 1} early (by win) on iteration {ii + 1}...")
                gameDone = True
                break

            currState = nextState
        # if gameDone:
        #     break
    print(Q)

    currState = (0, 0)
    while True:
        action = getMaxValidAction(currState)
        nextState = move(currState, action)
        print(f"Old state {currState} -> next state {nextState} with action {action}")
        currState = nextState
        if currState in icePositions:
            print("fail")
            break
        if currState == (3, 3):
            print("success!")
            break
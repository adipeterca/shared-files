import random
import numpy as np
from pprint import pprint
import copy
from tensorflow import keras
from keras.models import Sequential
from keras.layers import Dense, Activation
from keras import activations
from termcolor import colored

# Class used to remember past information
class Memory():
    def __init__(self, buffer_size = 1_000_000) -> None:
        self.buffer_size = buffer_size
        self.buffer = []
        self.idx = 0
        self.total_elements = 0

    def add(self, x):
        self.buffer.append(None)
        # self.buffer[self.idx] = copy.deepcopy(x)
        self.buffer[self.idx] = x
        self.idx = (self.idx + 1) % self.buffer_size

    def free(self):
        self.buffer = []
        self.idx = 0

    def size(self):
        return len(self.buffer)

# Given a state and an action, return the next state if it is a valid one, else return the current state
def step(curr_state, action):
    i, j = curr_state
    new_i, new_j = curr_state
    if action == UP:
        new_i = max(0, i - 1)
    elif action == DOWN:
        new_i = min(3, i + 1)
    elif action == LEFT:
        new_j = max(0, j - 1)
    elif action == RIGHT:
        new_j = min(3, j + 1)
    return new_i, new_j

# Builds a predefined Neural Network 2-100-4
def build_model():
    model = Sequential()
    model.add(Dense(100, input_shape=(2,), activation='relu'))
    model.add(Dense(4, activation='linear'))

    model.compile(loss="mean_squared_error", optimizer='adam')
    return model

def deep_copy_model(model):
    copied_model = keras.models.clone_model(model)
    copied_model.build((None, 2)) # replace 2 with number of variables in input layer
    copied_model.compile(optimizer='adam', loss='mean_squared_error')
    copied_model.set_weights(model.get_weights())
    return copied_model

def state_to_input(state):
    input_data = []
    state_i, state_j = state
    input_data.append(state_i)
    input_data.append(state_j)
    return np.array(input_data).reshape((2, 1)).T

def manhattan_distance(curr_state):
    i, j = curr_state
    return 6 - i - j
    
def distance(curr_state):
    i, j = curr_state
    return i + j

# List of wining states
winning_states = [(3, 3)]

# List of losing states
losing_states = [(1, 1), (1, 3), (2, 3), (3, 0)]

# Viable moves
UP = 0
DOWN = 1
LEFT = 2
RIGHT = 3

# # # Deep Q Learning variables
qnn = build_model()
tnn = deep_copy_model(qnn)
memory = Memory()

# Number of elements taken from memory to learn from
batch_size = 32

epsilon = 1.0

# Number of games played
num_episodes = 1500

# Frames per episode
frames_per_episode = 16
# # #

# Discount factor
gamma = 0.8

for e in range(num_episodes):
    # Starting state
    curr_state = (0, 0)
    done = "No Done"

    for frame in range(frames_per_episode):
        # print(f"{frame} of {e}...")
        memory.total_elements += 1
        if memory.total_elements < 5000:
            # random action if no more than 5000 moves have been visited
            a = random.choice([UP, DOWN, RIGHT, LEFT])
        else:
            if random.random() < epsilon:
                # epsilon-greedy action
                a = random.choice([UP, DOWN, RIGHT, LEFT])
            else:
                # qnn prediction
                curr_state_tensor = state_to_input(curr_state)
                prediction_tensor = qnn.predict(curr_state_tensor)[0]
                a = np.argmax(prediction_tensor)
            epsilon *= 0.95

        # Make the selected action and get the next state
        next_state = step(curr_state, a)

        curr_state_i, curr_state_j = curr_state
        next_state_i, next_state_j = next_state

        # If the state is the same
        if curr_state_i == next_state_i and curr_state_j == next_state_j:
            # R[curr_state_i][curr_state_j][a] = -1.0
            reward = -2.0
        elif next_state in winning_states:
            reward = 5.0
            done = "Win"
        elif next_state in losing_states:
            reward = -1.0
            done = "Dead"
        else:
            # reward = 0.0
            reward = distance(curr_state) / 10

        # persist the tuple <curr_state, move, reward, next_state>
        memory.add((curr_state, a, reward, next_state))

        # x = time.time()
        if frame % 2 == 0 and frame != 0 and memory.size() >= batch_size:
            batch = random.sample(memory.buffer, batch_size)
            features = []
            labels = []

            inputs = []
            for i in range(len(batch)):
                inputs.append(state_to_input(batch[i][0]))

            inputs = np.array(inputs).reshape((batch_size, 2))
            outputs_qnn = qnn.predict(inputs)

            inputs = []
            for i in range(len(batch)):
                inputs.append(state_to_input(batch[i][3]))

            inputs = np.array(inputs).reshape((batch_size, 2))
            outputs_tnn = tnn.predict(inputs)

            for idx, (_curr_state, _move, _reward, _next_state) in enumerate(batch):

                curr_state_tensor = state_to_input(_curr_state)
                next_state_tensor = state_to_input(_next_state)
                if _next_state in winning_states or _next_state in losing_states:
                    target = _reward
                else:
                    target = _reward + gamma * np.max(outputs_tnn[idx])
                target_tensor = outputs_qnn[idx].reshape((4, 1)).T
                target_tensor[0][_move] = target
                features.append(curr_state_tensor)
                labels.append(target_tensor)
            
            features = np.array(features).reshape((batch_size, 2))
            labels = np.array(labels).reshape((batch_size, 4))
            qnn.fit(features, labels, verbose=0)

        # Update the current state
        curr_state = next_state

        if done != "No Done":
            break
    
    # copy weight to target nn after episode finishes
    tnn = deep_copy_model(qnn)

    if done == "Win":
        print(colored(f'Finished episode {e} with {done} on frame {frame}', "green"))
    elif done == "Dead":
        print(colored(f'Finished episode {e} with {done} on frame {frame} on state {curr_state}', "red"))
    else:
        print(colored(f'Finished episode {e} with {done} on frame {frame} on state {curr_state}', "white"))

qnn.save('my_model')

# testing
curr_state = (0, 0)
print(curr_state)
while curr_state not in winning_states and curr_state not in losing_states:
    curr_state_tensor = state_to_input(curr_state)
    prediction_tensor = qnn.predict(curr_state_tensor)
    a = np.argmax(prediction_tensor)

    # update the game state
    curr_state = step(curr_state, a)
    print(curr_state)
import numpy as np
import random
import copy

def readData(path):
    with open(path, "r") as fin:
        buffer = fin.read()
        data = []
        for _line in buffer.splitlines():
            values = _line.split()
            arr = np.zeros((2, 1))
            arr[0][0] = int(values[0])
            arr[1][0] = int(values[1])
            data.append((copy.deepcopy(arr), int(values[2])))
        return data

# S(x) = 1 / (1 + e^(-x))
def sigmoidActivation(matrix):
    return 1 / (1 + np.exp(-matrix))

class NeuralNetwork:
    def __init__(self, lr = 0.5):
        self.weights_ih = np.random.uniform(low = 0, high = 1, size = (2, 2))
        self.bias_ih = np.random.random((2, 1))

        self.weights_ho = np.random.uniform(low = 0, high = 1, size = (1, 2))
        self.bias_ho = np.random.random((1, 1))

        # Default learning rate
        self.learningRate = lr

    def guess(self, inputs):
        # Calculate the weighted sum for INPUT to HIDDEN
        sum_ih = self.weights_ih.dot(inputs) + self.bias_ih

        sum_ih_activated = sigmoidActivation(sum_ih)

        # Calculate the weighted sum for HIDDEN to OUTPUT
        sum_ho = self.weights_ho.dot(sum_ih_activated) + self.bias_ho

        # Fire the neuron if the output is greater than 0.5
        return 1 if sigmoidActivation(sum_ho)[0][0] > 0.5 else 0

    def train(self, inputs, target):
        # Calculate the weighted sum for INPUT to HIDDEN
        sum_ih = self.weights_ih.dot(inputs) + self.bias_ih

        sum_ih_activated = sigmoidActivation(sum_ih)

        # Calculate the weighted sum for HIDDEN to OUTPUT
        sum_ho = self.weights_ho.dot(sum_ih_activated) + self.bias_ho
        
        sum_ho_activated = sigmoidActivation(sum_ho)

        output = np.zeros((1, 1))
        output[0][0] = 1 if sum_ho_activated[0][0] > 0.5 else 0
        # output = sigmoidActivation(sum_ho)

        # Calculate the errors 
        output_error = sum_ho_activated * (1 - sum_ho_activated) * (output - target)
        hidden_error = sum_ih_activated * (1 - sum_ih_activated) * (self.weights_ho.T.dot(output_error))

        # Calculate deltas
        weights_ih_delta = hidden_error.dot(inputs.T) * self.learningRate
        weights_ho_delta = output_error.dot(sum_ih_activated.T) * self.learningRate

        bias_ih_delta = hidden_error * self.learningRate
        bias_ho_delta = output_error * self.learningRate

        return weights_ih_delta, bias_ih_delta, weights_ho_delta, bias_ho_delta

    def runEpoch(self, _set):
        random.shuffle(_set)
        for inputs, target in _set:
            d1, d2, d3, d4 = self.train(inputs, target)

            # Debug mode
            # print("\nd1: \n", d1, "\nd2: \n", d2, "\nd3: \n", d3, "\nd4: \n", d4)

            # Update the weights
            self.weights_ih -= d1
            self.bias_ih -= d2
            self.weights_ho -= d3
            self.bias_ho -= d4

    def testAccuracy(self, _set):
        correct = 0
        total = 0
        for inputs, target in _set:
            total += 1
            guess = self.guess(inputs)
            if target == guess:
                correct += 1
            else:
                print(f"[TEST {total}] Guessed {guess} instead of {target}")
        
        print(f"Final accuracy: {correct}/{total}    {correct / total * 100}")
            
    # Returns whether or not the accuracy is maximum
    def shouldStop(self, _set):
        correct = 0
        total = 0
        for inputs, target in _set:
            total += 1
            guess = self.guess(inputs)
            if target == guess:
                correct += 1
        return correct == total

if __name__ == "__main__":
    train_set = readData("training_set.txt")
    test_set = readData("testing_set.txt")

    # 10000
    noOfEpochs = int(input("Number of epochs: "))
    # 0.5
    learningRate = float(input("Learning rate: "))

    nn = NeuralNetwork(learningRate)

    for e in  range(0, noOfEpochs):
        print(f"Running epoch {e}...")
        nn.runEpoch(train_set)
        # print(nn.weights_ih)
        # print(nn.weights_ho)
        # print(nn.bias_ho)
        # print(nn.bias_ih)
        # nn.testAccuracy(test_set)
    nn.testAccuracy(test_set)
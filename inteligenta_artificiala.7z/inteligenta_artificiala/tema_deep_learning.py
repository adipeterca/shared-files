import random

actions = {
    0: [(1, 0), (0, 1)],
    1: [(-1, 0), (1, 0), (0, 1)],
    2: [(-1, 0), (1, 0), (0, 1)],
    3: [(-1, 0), (0, 1)],
    4: [(0, -1), (1, 0), (0, 1)],
    5: [(0, -1), (1, 0), (0, 1), (-1, 0)],
    6: [(0, -1), (1, 0), (0, 1), (-1, 0)],
    7: [(0, -1), (0, 1), (-1, 0)],
    8: [(0, -1), (1, 0), (0, 1)],
    9: [(0, -1), (1, 0), (0, 1), (-1, 0)],
    10: [(0, -1), (1, 0), (0, 1), (-1, 0)],
    11: [(0, -1), (0, 1), (-1, 0)],
    12: [(0, -1), (1, 0)],
    13: [(-1, 0), (0, -1), (1, 0)],
    14: [(-1, 0), (0, -1), (1, 0)],
    15: []  # terminal state
}

# reward matrix
R = [0] * 16
R[5] = R[7] = R[11] = R[12] = -1
R[15] = 1

# Q matrix
Q = [0] * 16

# coordinates for states
coords = {
    0: (0, 0),
    1: (1, 0),
    2: (2, 0),
    3: (3, 0),
    4: (0, 1),
    5: (1, 1),
    6: (2, 1),
    7: (3, 1),
    8: (0, 2),
    9: (1, 2),
    10: (2, 2),
    11: (3, 2),
    12: (0, 3),
    13: (1, 3),
    14: (2, 3),
    15: (3, 3)
}


def step(curr_state, action):
    x, y = coords[curr_state]
    dx, dy = action
    x += dx
    y += dy
    return 4 * y + x


# training
num_episodes = 10
gamma = 0.8  # discount factor
for _ in range(num_episodes):
    curr_state = 0
    while curr_state != 15:
        a = random.choice(actions[curr_state])
        next_state = step(curr_state, a)
        if next_state != 15:
            max_reward = max([Q[step(next_state, a_prime)] for a_prime in actions[next_state]])
        else:
            max_reward = 0.0
        Q[next_state] = R[next_state] + gamma * max_reward
        curr_state = next_state

# testing
all_paths = []
for episode in range(num_episodes):
    curr_state = 0
    path = [0]
    while curr_state != 15:
        states_from_current = [step(curr_state, a) for a in actions[curr_state]]
        random.shuffle(states_from_current)
        next_state = None
        for state in states_from_current:
            if next_state is None or Q[state] > Q[next_state]:
                next_state = state
        curr_state = next_state
        path.append(curr_state)

    path_str = f'{path[0]}'
    for i in range(1, len(path)):
        path_str += f' -> {path[i]}'
    if path_str not in all_paths:
        all_paths.append(path_str)

for i, path in enumerate(all_paths):
    print(f'path #{i + 1}: {path}')